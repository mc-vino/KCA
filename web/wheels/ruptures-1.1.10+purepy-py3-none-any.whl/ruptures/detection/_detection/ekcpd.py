"""Заглушка C-расширения ruptures: под wasm оно не собирается.

Расширение нужно только KernelCPD. §5.8.4 использует Pelt, и он работает без
него: 44 точки разладки на девяти калибровочных кассах §11.3 совпали с
обычной сборкой ruptures до одной. Вызов даёт явную ошибку, а не
правдоподобное число (§0.3 «отказ вместо догадки»).
"""


def ekcpd_cosine(*args, **kwargs):
    message = "KernelCPD недоступен: C-расширение ruptures не собрано под wasm"
    raise NotImplementedError(message)


def ekcpd_Gaussian(*args, **kwargs):
    message = "KernelCPD недоступен: C-расширение ruptures не собрано под wasm"
    raise NotImplementedError(message)


def ekcpd_L2(*args, **kwargs):
    message = "KernelCPD недоступен: C-расширение ruptures не собрано под wasm"
    raise NotImplementedError(message)


def ekcpd_pelt_cosine(*args, **kwargs):
    message = "KernelCPD недоступен: C-расширение ruptures не собрано под wasm"
    raise NotImplementedError(message)


def ekcpd_pelt_Gaussian(*args, **kwargs):
    message = "KernelCPD недоступен: C-расширение ruptures не собрано под wasm"
    raise NotImplementedError(message)


def ekcpd_pelt_L2(*args, **kwargs):
    message = "KernelCPD недоступен: C-расширение ruptures не собрано под wasm"
    raise NotImplementedError(message)
